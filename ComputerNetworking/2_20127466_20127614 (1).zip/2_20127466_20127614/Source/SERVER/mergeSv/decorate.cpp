//#define CURL_STATICLIB
//#include"pch.h"
//#include "framework.h"
//#include "mergesv.h"
//#include "afxsock.h"
//#include"pch.h"
//#include<iostream>
//#include<fstream>
//#include<sstream>
//#include<vector>
//#include<string>
//#include<sstream>
//#include<thread>
//#include<curl/curl.h>
//#include"Header.h"
//#include<Windows.h>
//using namespace std;
//#ifdef _DEBUG
//#define new DEBUG_NEW
//#define SIZE 2
//#endif
//
////int cnt = 1;
//// The one and only application object
//
//
//void GotoXY(int x, int y)
//{
//	COORD coord;
//	coord.X = x;
//	coord.Y = y;
//	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
//}
//
//
//
//void SetTColor(WORD color)
//{
//	HANDLE hConsoleOutput;
//	hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
//	CONSOLE_SCREEN_BUFFER_INFO screen_buffer_info;
//	GetConsoleScreenBufferInfo(hConsoleOutput, &screen_buffer_info);
//	WORD wAttributes = screen_buffer_info.wAttributes;
//	color &= 0x000f;
//	wAttributes &= 0xfff0; wAttributes |= color;
//	SetConsoleTextAttribute(hConsoleOutput, wAttributes);
//}