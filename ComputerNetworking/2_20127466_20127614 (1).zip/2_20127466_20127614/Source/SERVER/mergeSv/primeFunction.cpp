#include"pch.h"
#include"primeFunction.h"
#include"secFunction.h"
#include<sstream>
#include<thread>
#include<curl/curl.h>

void  update30(string filename)
{
	while (1)
	{
		
		createDatabase(filename);
		//cout << endl << "dang cap nhat du lieu...";
		Sleep(1800000);
	}
}

void cleanData(string data, string name, TIENTE& t)
{
	t.ten = name;
	size_t distance1 = data.find(name) + 27;
	size_t pos1 = data.find(">", distance1 - 2);
	size_t pos2 = data.find("<", pos1);
	size_t numberOfDigit = pos2 - pos1 - 1;
	t.tyGiaTT = data.substr(distance1, numberOfDigit);

	distance1 = distance1 + numberOfDigit + 24;
	pos1 = data.find(">", distance1 - 2);
	pos2 = data.find("<", pos1);
	numberOfDigit = pos2 - pos1 - 1;
	t.tyGiaMua.tienMat = data.substr(distance1, numberOfDigit);

	distance1 = distance1 + numberOfDigit + 24;
	pos1 = data.find(">", distance1 - 2);
	pos2 = data.find("<", pos1);
	numberOfDigit = pos2 - pos1 - 1;
	t.tyGiaMua.chuyenKhoan = data.substr(distance1, numberOfDigit);

	distance1 = distance1 + numberOfDigit + 24;
	pos1 = data.find(">", distance1 - 2);
	pos2 = data.find("<", pos1);
	numberOfDigit = pos2 - pos1 - 1;
	t.tyGiaBan = data.substr(distance1, numberOfDigit);

	if (name == "EUR")
	{
		distance1 = distance1 + numberOfDigit + 98;
		pos1 = data.find(">", distance1 - 2);
		pos2 = data.find("<", pos1);
		numberOfDigit = pos2 - pos1 - 1;
		t.note = data.substr(distance1, numberOfDigit);
		distance1 = distance1 + numberOfDigit + 24;
	}
	if (name == "USD")
	{
		distance1 = distance1 + numberOfDigit + 97;
		pos1 = data.find(">", distance1 - 2);
		pos2 = data.find("<", pos1);
		numberOfDigit = pos2 - pos1 - 1;
		t.note = data.substr(distance1, numberOfDigit);
		distance1 = distance1 + numberOfDigit + 24;
	}
}
static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp)
{
	((string*)userp)->append((char*)contents, size * nmemb);
	return size * nmemb;
}
bool crawlDataFromWebToFile(string fileName, TIENTE tienTe[], string& data, string url, string nameCurrent[]) {
	CURL* curl;
	CURLcode res;
	string readBuffer;

	curl = curl_easy_init();
	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
		res = curl_easy_perform(curl);
		curl_easy_cleanup(curl);
		size_t indexStart = readBuffer.find("<body>");
		size_t indexEnd = readBuffer.find("</body>", indexStart);
		data = readBuffer.substr(indexStart, indexEnd - indexStart);

		if (data.find("Không có bảng tỷ giá") == -1)
			return true;
		return false;
	}
}

void createDatabase(string fileName)
{

	TODAY td;
	TIENTE tienTe[17];
	string data;
	int day, month, year;
	currentDay(day, month, year);
	string nameCurent[17] = { "AUD","CAD","CHF", "CNY", "DKK", "EUR","GBP", "HKD",
							"JPY","KRW","LAK","NOK","NZD","SEK","SGD","THB","USD" };
	ofstream f;
	f.open(fileName);
	for (int i = 5; i > 0; i--)
	{
		string url = "https://www.vietinbank.vn/web/home/vn/ty-gia/?theDate=";
		if (day < 10)
			td.d = "0" + to_string(day);
		else
			td.d = to_string(day);
		if (month < 10)
			td.m = "0" + to_string(month);
		else
			td.m = to_string(month);
		td.y = to_string(year);
		url += td.d + "%2F" + td.m + "%2F" + td.y;
		if (crawlDataFromWebToFile("data.txt", tienTe, data, url, nameCurent) == true)
		{

			f << td.d << "|" << td.m << "|" << td.y << "\n";
			for (int i = 0; i < 17; i++)
			{
				cleanData(data, nameCurent[i], tienTe[i]);
				f << tienTe[i].ten << " " << tienTe[i].tyGiaTT << " " << tienTe[i].tyGiaMua.tienMat << " " << tienTe[i].tyGiaMua.chuyenKhoan << " ";
				f << tienTe[i].tyGiaBan << " " << tienTe[i].note;
				f << "\n";
			}
		}
		else
		{
			string inforDate = "EMPTY\n";
			f << inforDate;
		}
		yesterday(day, month, year);
	}
	f.close();
}

bool loadData1(TIENTE& tienTe, string tenTraCuu, string& inforDate)
{
	string d, m, y;
	ifstream f;
	f.open("data.txt");
	string lineInfor, buf;
	int i = 0;

	while (!f.eof())
	{
		getline(f, lineInfor);
		if (lineInfor != "EMPTY") {
			inforDate = lineInfor;
			do {
				getline(f, lineInfor);
				stringstream buf(lineInfor);
				getline(buf, tienTe.ten, ' ');
				getline(buf, tienTe.tyGiaTT, ' ');
				getline(buf, tienTe.tyGiaMua.tienMat, ' ');
				getline(buf, tienTe.tyGiaMua.chuyenKhoan, ' ');
				getline(buf, tienTe.tyGiaBan, ' ');
				getline(buf, tienTe.note, ' ');
			} while (tenTraCuu != tienTe.ten);
			return true;
		}
	}
	f.close();
	return false;
}
//lay thong tin theo ngay
bool loadData2(TIENTE tienTe[], string day, string month, string year)
{
	string d, m, y;
	ifstream f;
	f.open("data.txt");
	string lineInfor, buf;
	int i = 0;
	//	getline(f, lineInfor);

	while (!f.eof())
	{
		getline(f, lineInfor);
		if (lineInfor != "EMPTY") {
			stringstream buf(lineInfor);
			getline(buf, d, '|');
			getline(buf, m, '|');
			getline(buf, y, '\n');
			for (int i = 0; i < 17; i++)
			{
				getline(f, lineInfor);
				stringstream buf(lineInfor);
				getline(buf, tienTe[i].ten, ' ');
				getline(buf, tienTe[i].tyGiaTT, ' ');
				getline(buf, tienTe[i].tyGiaMua.tienMat, ' ');
				getline(buf, tienTe[i].tyGiaMua.chuyenKhoan, ' ');
				getline(buf, tienTe[i].tyGiaBan, ' ');
				getline(buf, tienTe[i].note, ' ');
			}
		}
		if (d == day && m == month && y == year)
		{
			f.close();	return true;
		}
	}
	f.close();
	return false;
}

void saveFile(string path, USER user)
{
	ofstream fout;
	fout.open(path, ios::app);
	fout << user.u << " " << user.p << "\n";
	fout.close();
}
bool is_emptyFile(ifstream& pFile)
{
	return pFile.peek() == ifstream::traits_type::eof();
}
int checkUser(string path, USER user, int check)
{
	ifstream fin;
	fin.open(path);

	if (is_emptyFile(fin))
		return 0;
	else
	{
		USER buf;
		while (!fin.eof())
		{
			getline(fin, buf.u, ' ');
			getline(fin, buf.p, '\n');
			if (check == 1)//kierm tra dang ki
			{
				if (user.u == buf.u)
					return 1;
			}
			else
				if (user.u == buf.u && user.p == buf.p)
					return 1;
		}
	}
	return 0;
}
DWORD WINAPI function_cal(LPVOID arg)
{
	SOCKET* hConnected = (SOCKET*)arg;
	CSocket cl1;
	//Chuyen ve lai CSocket
	cl1.Attach(*hConnected);


	string s;
	int len;
	char* r = NULL;
	int check;
	int flag = 1, flag1 = 1;
	while (1)
	{
		//dau tien seve nhan cac tin hieu signin/up exit tu client
		check = 0;
		s = response(cl1);
		if (s == "exit")
		{
			//bao gioừ làm hoàn chỉnh sẽ ghi thêm ip của client
			cout << "\n\t\t\t\t\t1 client vua thoat.";
			break;
		}
		if (s == "sign in")
		{
			USER u1;
			//nhan pass va user
			u1.u = response(cl1);
			if (u1.u == "\0")
				break;
			u1.p = response(cl1);
			//kiem tra co ton tai trong file chua
			if (checkUser("inforUser.txt", u1, 0) == 1)
			{//phan hoi 1 neu thanh cong, 0 neu that bai
				resquest(cl1, "1");
				cout << "\n\t\t\t\t\tClient: " << u1.u << " vua dang nhap thanh cong ";
				//vo phan tra cuu
				while (1)
				{
					s = response(cl1);
					if (s == "\0")
						break;
					if (s == "1")
					{
						string inforDate = "0";
						TIENTE tienTe;
						s = response(cl1);
						if (s == "\0")
							break;
						if (loadData1(tienTe, s, inforDate) == false)
						{
							inforDate = "Khong co thong tin";
							resquest(cl1, "0");
						}
						else {
							resquest(cl1, "1");
							resquest(cl1, tienTe.ten);
							resquest(cl1, tienTe.tyGiaTT);
							resquest(cl1, tienTe.tyGiaMua.tienMat);
							resquest(cl1, tienTe.tyGiaMua.chuyenKhoan);
							resquest(cl1, tienTe.tyGiaBan);
							resquest(cl1, tienTe.note);
						}
						resquest(cl1, inforDate);
					}
					//	tra cuu theo ngay
					else	if (s == "2")
					{
						string inforDate = "0";
						TIENTE tienTe[17];
						string day = response(cl1);
						if (day == "\0")
							break;
						string month = response(cl1);
						string year = response(cl1);

						if (loadData2(tienTe, day, month, year) == false)
						{
							inforDate = "Khong co thong tin bang ty gia ngay: " + day + "|" + month + "|" + year;
							resquest(cl1, "0");
						}
						else {
							resquest(cl1, "1");
							for (int i = 0; i < 17; i++)
							{
								resquest(cl1, tienTe[i].ten);
								resquest(cl1, tienTe[i].tyGiaTT);
								resquest(cl1, tienTe[i].tyGiaMua.tienMat);
								resquest(cl1, tienTe[i].tyGiaMua.chuyenKhoan);
								resquest(cl1, tienTe[i].tyGiaBan);
								resquest(cl1, tienTe[i].note);
							}
							inforDate = "ngay " + day + "/" + month + "/" + year;
						}
						resquest(cl1, inforDate);
					}
					if (s == "0")
						break;
				}//ket thuc tra cuu

			}
			else
				resquest(cl1, "0");
		}
		if (s == "sign up")
		{
			USER u1;
			s = response(cl1);
			if (s == "1")
			{
				u1.u = response(cl1);
				if (u1.u == "\0")
					break;
				u1.p = response(cl1);
				if (checkUser("inforUser.txt", u1, 1) == 0) {
					saveFile("inforUser.txt", u1);
					cout << endl << "\t\t\t\t\tClient: " << u1.u  << " dang ky tai khoan thanh cong";
					resquest(cl1, "1");
				}
				else resquest(cl1, "0");
			}
			if (s == "0")
				resquest(cl1, "0");
		}
		// 1 la chay, 0 la thoat
	}
	cl1.Close();
	delete hConnected;
	return 0;
}