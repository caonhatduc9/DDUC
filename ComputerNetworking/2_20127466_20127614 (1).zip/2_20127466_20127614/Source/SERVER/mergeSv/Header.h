#pragma once
#define CURL_STATICLIB
#include"pch.h"
#include "framework.h"
#include "mergesv.h"
#include "afxsock.h"
#include"pch.h"
#include<iostream>
#include<fstream>
#include<sstream>
#include<vector>
#include<string>
#include<sstream>
#include<thread>
#include<curl/curl.h>
using namespace std;
#ifdef _DEBUG
#define new DEBUG_NEW
#define SIZE 2
#endif

struct MUA {
	string tienMat, chuyenKhoan;
};
struct TIENTE {
	string ten, tyGiaTT, tyGiaBan, note;
	MUA tyGiaMua;
};
struct TODAY {
	string d, m, y;
};
struct USER {
	string u, p;
};
void currentDay(int& day, int& month, int& year);
bool isLeepYear(int nYear);
int dayOfMonth(int nMonth, int nYear);
void yesterday(int& nDay, int& nMonth, int& nYear);
void cleanData(string data, string name, TIENTE& t);
static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp);
bool crawlDataFromWebToFile(string fileName, TIENTE tienTe[], string& data, string url, string nameCurrent[]);
void createDatabase(string fileName);
bool loadData1(TIENTE& tienTe, string tenTraCuu, string& inforDate);
bool loadData2(TIENTE tienTe[], string day, string month, string year);
void GotoXY(int x, int y);
int resquest(CSocket& cs, string s);
char* response(CSocket& c);
void saveFile(string path, USER user);
bool is_emptyFile(ifstream& pFile);
int checkUser(string path, USER user, int check);
DWORD WINAPI function_cal(LPVOID arg);
void SetTColor(WORD color);
void clearData(string filename);
void  update30(string filename);

