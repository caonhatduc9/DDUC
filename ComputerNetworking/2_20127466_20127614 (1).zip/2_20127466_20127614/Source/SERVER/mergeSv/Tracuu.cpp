﻿//#define CURL_STATICLIB
//#include"pch.h"
//#include "framework.h"
//#include "mergesv.h"
//#include "afxsock.h"
//#include"pch.h"
//#include<iostream>
//#include<fstream>
//#include<sstream>
//#include<vector>
//#include<string>
//#include<sstream>
//#include<thread>
//#include"Header.h"
//
//#include<curl/curl.h>
//using namespace std;
//#ifdef _DEBUG
//#define new DEBUG_NEW
//#define SIZE 2
//#endif
//
////int cnt = 1;
//// The one and only application object
////chia qua file chi dung cho ngay thang nam
//void currentDay(int& day, int& month, int& year)
//{
//	time_t now = time(0);
//	tm ltm;
//	localtime_s(&ltm, &now);
//	day = ltm.tm_mday;
//	month = ltm.tm_mon + 1;
//	year = ltm.tm_year + 1900;
//}
//bool isLeepYear(int nYear)
//{
//	if ((nYear % 4 == 0 && nYear % 100 != 0) || nYear % 400 == 0)
//	{
//		return true;
//	}
//	return false;
//}
//int dayOfMonth(int nMonth, int nYear)
//{
//	int nNumOfDays;
//
//	switch (nMonth)
//	{
//	case 1:
//	case 3:
//	case 5:
//	case 7:
//	case 8:
//	case 10:
//	case 12:
//		nNumOfDays = 31;
//		break;
//	case 4:
//	case 6:
//	case 9:
//	case 11:
//		nNumOfDays = 30;
//		break;
//	case 2:
//		if (isLeepYear(nYear))
//		{
//			nNumOfDays = 29;
//		}
//		else
//		{
//			nNumOfDays = 28;
//		}
//		break;
//	}
//
//	return nNumOfDays;
//}
//void yesterday(int& nDay, int& nMonth, int& nYear)
//{
//	nDay--;
//	if (nDay == 0)
//	{
//		nMonth--;
//		if (nMonth == 0)
//		{
//			nMonth = 12;
//			nYear--;
//		}
//		nDay = dayOfMonth(nMonth, nYear);
//	}
//}
//
//
//void cleanData(string data, string name, TIENTE& t)
//{
//	t.ten = name;
//	size_t distance1 = data.find(name) + 27;
//	size_t pos1 = data.find(">", distance1 - 2);
//	size_t pos2 = data.find("<", pos1);
//	size_t numberOfDigit = pos2 - pos1 - 1;
//	t.tyGiaTT = data.substr(distance1, numberOfDigit);
//
//	distance1 = distance1 + numberOfDigit + 24;
//	pos1 = data.find(">", distance1 - 2);
//	pos2 = data.find("<", pos1);
//	numberOfDigit = pos2 - pos1 - 1;
//	t.tyGiaMua.tienMat = data.substr(distance1, numberOfDigit);
//
//	distance1 = distance1 + numberOfDigit + 24;
//	pos1 = data.find(">", distance1 - 2);
//	pos2 = data.find("<", pos1);
//	numberOfDigit = pos2 - pos1 - 1;
//	t.tyGiaMua.chuyenKhoan = data.substr(distance1, numberOfDigit);
//
//	distance1 = distance1 + numberOfDigit + 24;
//	pos1 = data.find(">", distance1 - 2);
//	pos2 = data.find("<", pos1);
//	numberOfDigit = pos2 - pos1 - 1;
//	t.tyGiaBan = data.substr(distance1, numberOfDigit);
//
//	if (name == "EUR")
//	{
//		distance1 = distance1 + numberOfDigit + 98;
//		pos1 = data.find(">", distance1 - 2);
//		pos2 = data.find("<", pos1);
//		numberOfDigit = pos2 - pos1 - 1;
//		t.note = data.substr(distance1, numberOfDigit);
//		distance1 = distance1 + numberOfDigit + 24;
//	}
//	if (name == "USD")
//	{
//		distance1 = distance1 + numberOfDigit + 97;
//		pos1 = data.find(">", distance1 - 2);
//		pos2 = data.find("<", pos1);
//		numberOfDigit = pos2 - pos1 - 1;
//		t.note = data.substr(distance1, numberOfDigit);
//		distance1 = distance1 + numberOfDigit + 24;
//	}
//}
//
//static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp)
//{
//	((string*)userp)->append((char*)contents, size * nmemb);
//	return size * nmemb;
//}
//
//bool crawlDataFromWebToFile(string fileName, TIENTE tienTe[], string& data, string url, string nameCurrent[]) {
//	CURL* curl;
//	CURLcode res;
//	string readBuffer;
//
//	curl = curl_easy_init();
//	if (curl) {
//		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
//		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
//		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
//		res = curl_easy_perform(curl);
//		curl_easy_cleanup(curl);
//		size_t indexStart = readBuffer.find("<body>");
//		size_t indexEnd = readBuffer.find("</body>", indexStart);
//		data = readBuffer.substr(indexStart, indexEnd - indexStart);
//
//		if (data.find("Không có bảng tỷ giá") == -1)
//			return true;
//		return false;
//	}
//}
//
//void createDatabase(string fileName)
//{
//
//	TODAY td;
//	TIENTE tienTe[17];
//	string data;
//	int day, month, year;
//	currentDay(day, month, year);
//	string nameCurent[17] = { "AUD","CAD","CHF", "CNY", "DKK", "EUR","GBP", "HKD",
//							"JPY","KRW","LAK","NOK","NZD","SEK","SGD","THB","USD" };
//	ofstream f;
//	f.open(fileName);
//	for (int i = 5; i > 0; i--)
//	{
//		string url = "https://www.vietinbank.vn/web/home/vn/ty-gia/?theDate=";
//		if (day < 10)
//			td.d = "0" + to_string(day);
//		else
//			td.d = to_string(day);
//		if (month < 10)
//			td.m = "0" + to_string(month);
//		else
//			td.m = to_string(month);
//		td.y = to_string(year);
//		url += td.d + "%2F" + td.m + "%2F" + td.y;
//		if (crawlDataFromWebToFile("data.txt", tienTe, data, url, nameCurent) == true)
//		{
//
//			f << td.d << "|" << td.m << "|" << td.y << "\n";
//			for (int i = 0; i < 17; i++)
//			{
//				cleanData(data, nameCurent[i], tienTe[i]);
//				f << tienTe[i].ten << " " << tienTe[i].tyGiaTT << " " << tienTe[i].tyGiaMua.tienMat << " " << tienTe[i].tyGiaMua.chuyenKhoan << " ";
//				f << tienTe[i].tyGiaBan << " " << tienTe[i].note;
//				f << "\n";
//			}
//		}
//		else
//		{
//			string inforDate = "EMPTY\n";
//			f << inforDate;
//		}
//		yesterday(day, month, year);
//	}
//	f.close();
//}
//
//
//
////lay thong tin theo ten
//bool loadData1(TIENTE& tienTe, string tenTraCuu, string& inforDate)
//{
//	string d, m, y;
//	ifstream f;
//	f.open("data.txt");
//	string lineInfor, buf;
//	int i = 0;
//
//	while (!f.eof())
//	{
//		getline(f, lineInfor);
//		if (lineInfor != "EMPTY") {
//			inforDate = lineInfor;
//			do {
//				getline(f, lineInfor);
//				stringstream buf(lineInfor);
//				getline(buf, tienTe.ten, ' ');
//				getline(buf, tienTe.tyGiaTT, ' ');
//				getline(buf, tienTe.tyGiaMua.tienMat, ' ');
//				getline(buf, tienTe.tyGiaMua.chuyenKhoan, ' ');
//				getline(buf, tienTe.tyGiaBan, ' ');
//				getline(buf, tienTe.note, ' ');
//			} while (tenTraCuu != tienTe.ten);
//			return true;
//		}
//	}
//	f.close();
//	return false;
//}
////lay thong tin theo ngay
//bool loadData2(TIENTE tienTe[], string day, string month, string year)
//{
//	string d, m, y;
//	ifstream f;
//	f.open("data.txt");
//	string lineInfor, buf;
//	int i = 0;
//	//	getline(f, lineInfor);
//
//	while (!f.eof())
//	{
//		getline(f, lineInfor);
//		if (lineInfor != "EMPTY") {
//			stringstream buf(lineInfor);
//			getline(buf, d, '|');
//			getline(buf, m, '|');
//			getline(buf, y, '\n');
//			for (int i = 0; i < 17; i++)
//			{
//				getline(f, lineInfor);
//				stringstream buf(lineInfor);
//				getline(buf, tienTe[i].ten, ' ');
//				getline(buf, tienTe[i].tyGiaTT, ' ');
//				getline(buf, tienTe[i].tyGiaMua.tienMat, ' ');
//				getline(buf, tienTe[i].tyGiaMua.chuyenKhoan, ' ');
//				getline(buf, tienTe[i].tyGiaBan, ' ');
//				getline(buf, tienTe[i].note, ' ');
//			}
//		}
//		if (d == day && m == month && y == year)
//		{
//			f.close();	return true;
//		}
//	}
//	f.close();
//	return false;
//}
//void clearData(string filename)
//{
//	ofstream filein(filename);
//	if (filein.is_open())
//	{
//		while (!filein.good())
//		{
//			filein << " ";
//		}
//	}
//}
//void  update30(string filename)
//{
//	while (1)
//	{
//		//clearData(filename);
//		createDatabase(filename);
//		cout << endl << "";
//		Sleep(1800000);
//	}
//}