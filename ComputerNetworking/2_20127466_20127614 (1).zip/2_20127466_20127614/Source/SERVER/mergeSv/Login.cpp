﻿//#define CURL_STATICLIB
//#include"pch.h"
//#include "framework.h"
//#include "mergesv.h"
//#include "afxsock.h"
//#include"pch.h"
//#include<iostream>
//#include<fstream>
//#include<sstream>
//#include<vector>
//#include<string>
//#include<sstream>
//#include<thread>
//#include<curl/curl.h>
//#include"Header.h"
//using namespace std;
//#ifdef _DEBUG
//#define new DEBUG_NEW
//#define SIZE 2
//#endif
//
////int cnt = 1;
//// The one and only application object
//
//int resquest(CSocket& cs, string s) {
//	int len = s.length();
//	cs.Send(&len, sizeof(int), 0);
//	cs.Send(s.c_str(), len, 0);
//	return len;
//}
//char* response(CSocket& c)
//{
//	char* r;
//	int len;
//	c.Receive(&len, sizeof(int), 0);
//	if (len < 0) {
//		r = new char[1];
//		strcpy_s(r, 2, "\0");
//		return r;
//	}
//	r = new char[len];
//	c.Receive(r, len, 0);
//	r[len] = 0;
//	return r;
//}
//void saveFile(string path, USER user)
//{
//	ofstream fout;
//	fout.open(path, ios::app);
//	fout << user.u << " " << user.p << "\n";
//	fout.close();
//}
//bool is_emptyFile(ifstream& pFile)
//{
//	return pFile.peek() == ifstream::traits_type::eof();
//}
//int checkUser(string path, USER user, int check)
//{
//	ifstream fin;
//	fin.open(path);
//
//	if (is_emptyFile(fin))
//		return 0;
//	else
//	{
//		USER buf;
//		while (!fin.eof())
//		{
//			getline(fin, buf.u, ' ');
//			getline(fin, buf.p, '\n');
//			if (check == 1)//kierm tra dang ki
//			{
//				if (user.u == buf.u)
//					return 1;
//			}
//			else
//				if (user.u == buf.u && user.p == buf.p)
//					return 1;
//		}
//	}
//	return 0;
//}
//DWORD WINAPI function_cal(LPVOID arg)
//{
//	SOCKET* hConnected = (SOCKET*)arg;
//	CSocket cl1;
//	//Chuyen ve lai CSocket
//	cl1.Attach(*hConnected);
//
//
//	string s;
//	int len;
//	char* r = NULL;
//	int check;
//	int flag = 1, flag1 = 1;
//	while (1)
//	{
//		//dau tien seve nhan cac tin hieu signin/up exit tu client
//		check = 0;
//		s = response(cl1);
//		if (s == "exit")
//		{
//			//bao gioừ làm hoàn chỉnh sẽ ghi thêm ip của client
//			cout << "\n\t\t\t\t\tclient just close";
//			break;
//		}
//		if (s == "sign in")
//		{
//			USER u1;
//			//nhan pass va user
//			u1.u = response(cl1);
//			if (u1.u == "\0")
//				break;
//			u1.p = response(cl1);
//			//kiem tra co ton tai trong file chua
//			if (checkUser("inforUser.txt", u1, 0) == 1)
//			{//phan hoi 1 neu thanh cong, 0 neu that bai
//				resquest(cl1, "1");
//				cout << "\n\t\t\t\t\tUser: " << u1.u << " has been signed in successfully ";
//				//vo phan tra cuu
//				while (1)
//				{
//					s = response(cl1);
//					if (s == "\0")
//						break;
//					if (s == "1")
//					{
//						string inforDate = "0";
//						TIENTE tienTe;
//						s = response(cl1);
//						if (s == "\0")
//							break;
//						if (loadData1(tienTe, s, inforDate) == false)
//						{
//							inforDate = "Khong co thong tin";
//							resquest(cl1, "0");
//						}
//						else {
//							resquest(cl1, "1");
//							resquest(cl1, tienTe.ten);
//							resquest(cl1, tienTe.tyGiaTT);
//							resquest(cl1, tienTe.tyGiaMua.tienMat);
//							resquest(cl1, tienTe.tyGiaMua.chuyenKhoan);
//							resquest(cl1, tienTe.tyGiaBan);
//							resquest(cl1, tienTe.note);
//						}
//						resquest(cl1, inforDate);
//					}
//					//	tra cuu theo ngay
//					else	if (s == "2")
//					{
//						string inforDate = "0";
//						TIENTE tienTe[17];
//						string day = response(cl1);
//						if (day == "\0")
//							break;
//						string month = response(cl1);
//						string year = response(cl1);
//
//						if (loadData2(tienTe, day, month, year) == false)
//						{
//							inforDate = "Khong co thong tin bang ty gia ngay: " + day + "|" + month + "|" + year;
//							resquest(cl1, "0");
//						}
//						else {
//							resquest(cl1, "1");
//							for (int i = 0; i < 17; i++)
//							{
//								resquest(cl1, tienTe[i].ten);
//								resquest(cl1, tienTe[i].tyGiaTT);
//								resquest(cl1, tienTe[i].tyGiaMua.tienMat);
//								resquest(cl1, tienTe[i].tyGiaMua.chuyenKhoan);
//								resquest(cl1, tienTe[i].tyGiaBan);
//								resquest(cl1, tienTe[i].note);
//							}
//							inforDate = "ngay " + day + "/" + month + "/" + year;
//						}
//						resquest(cl1, inforDate);
//					}
//					if (s == "0")
//						break;
//				}//ket thuc tra cuu
//
//			}
//			else
//				resquest(cl1, "0");
//		}
//		if (s == "sign up")
//		{
//
//			USER u1;
//			s = response(cl1);
//			if (s == "1")
//			{
//				u1.u = response(cl1);
//				if (u1.u == "\0")
//					break;
//				u1.p = response(cl1);
//				if (checkUser("inforUser.txt", u1, 1) == 0) {
//					saveFile("inforUser.txt", u1);
//					cout << endl << "\t\t\t\t\tUser: '" << u1.u << "'" << " has already been registered successfully";
//					resquest(cl1, "1");
//				}
//				else resquest(cl1, "0");
//			}
//			if (s == "0")
//				resquest(cl1, "0");
//		}
//
//		// 1 la chay, 0 la thoat
//	}
//	cl1.Close();
//	delete hConnected;
//
//	return 0;
//	//return 0;
//}