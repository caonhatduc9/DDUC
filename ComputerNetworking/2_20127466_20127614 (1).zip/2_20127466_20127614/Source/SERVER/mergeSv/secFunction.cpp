#include"pch.h"
#include"secFunction.h"

void currentDay(int& day, int& month, int& year)
{
	time_t now = time(0);
	tm ltm;
	localtime_s(&ltm, &now);
	day = ltm.tm_mday;
	month = ltm.tm_mon + 1;
	year = ltm.tm_year + 1900;
}
bool isLeepYear(int nYear)
{
	if ((nYear % 4 == 0 && nYear % 100 != 0) || nYear % 400 == 0)
	{
		return true;
	}
	return false;
}
int dayOfMonth(int nMonth, int nYear)
{
	int nNumOfDays;
	switch (nMonth)
	{
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		nNumOfDays = 31;
		break;
	case 4:
	case 6:
	case 9:
	case 11:
		nNumOfDays = 30;
		break;
	case 2:
		if (isLeepYear(nYear))
		{
			nNumOfDays = 29;
		}
		else
		{
			nNumOfDays = 28;
		}
		break;
	}

	return nNumOfDays;
}
void yesterday(int& nDay, int& nMonth, int& nYear)
{
	nDay--;
	if (nDay == 0)
	{
		nMonth--;
		if (nMonth == 0)
		{
			nMonth = 12;
			nYear--;
		}
		nDay = dayOfMonth(nMonth, nYear);
	}
}

int resquest(CSocket& cs, string s) {
	int len = s.length();
	cs.Send(&len, sizeof(int), 0);
	cs.Send(s.c_str(), len, 0);
	return len;
}
char* response(CSocket& c)
{
	char* r;
	int len;
	c.Receive(&len, sizeof(int), 0);
	if (len < 0) {
		r = new char[1];
		strcpy_s(r, 2, "\0");
		return r;
	}
	r = new char[len];
	c.Receive(r, len, 0);
	r[len] = 0;
	return r;
}
void SetTColor(WORD color)
{
	HANDLE hConsoleOutput;
	hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO screen_buffer_info;
	GetConsoleScreenBufferInfo(hConsoleOutput, &screen_buffer_info);
	WORD wAttributes = screen_buffer_info.wAttributes;
	color &= 0x000f;
	wAttributes &= 0xfff0; wAttributes |= color;
	SetConsoleTextAttribute(hConsoleOutput, wAttributes);
}