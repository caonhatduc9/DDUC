#include<Windows.h>
#include "pch.h"
#include "framework.h"
#include "CLIENT.h"
#include"afxsock.h"
#include"string.h"
#include <string>
#include<vector>
#include<conio.h>
#include<iostream>
#define chieudai 75
#define chieurong 10
#define chieurong1 8
#define chieudai2 80
#define chieurong2 25
using namespace std;
void GotoXY(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void SetTColor(WORD color)
{
	HANDLE hConsoleOutput;
	hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO screen_buffer_info;
	GetConsoleScreenBufferInfo(hConsoleOutput, &screen_buffer_info);
	WORD wAttributes = screen_buffer_info.wAttributes;
	color &= 0x000f;
	wAttributes &= 0xfff0; wAttributes |= color;
	SetConsoleTextAttribute(hConsoleOutput, wAttributes);
}
void FixConsoleWindow()
{
	HWND consoleWindow = GetConsoleWindow();
	LONG style = GetWindowLong(consoleWindow, GWL_STYLE);
	style = style & ~(WS_MAXIMIZEBOX) & ~(WS_THICKFRAME);
	SetWindowLong(consoleWindow, GWL_STYLE, style);
}
void noCursorType()
{
	CONSOLE_CURSOR_INFO info;
	info.bVisible = FALSE;
	info.dwSize = 20;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info);
}

void DrawBoard2()
{
	SetTColor(1);
	GotoXY(35, 0);
	cout << "KET QUA:";
	GotoXY(2, 1);
	for (int i = 1; i <= chieudai2 + 1; i++)
		cout << char(220);
	GotoXY(2, 5);
	for (int i = 1; i <= chieudai2 + 1; i++)
		cout << char(220);
	for (int i = 2; i < chieurong2; i++)
	{
		GotoXY(17, i);
		cout << char(219);
	}
	for (int i = 2; i < chieurong2; i++)
	{
		GotoXY(37, i);
		cout << char(219);
	}
	for (int i = 2; i < chieurong2; i++)
	{
		GotoXY(66, i);
		cout << char(219);
	}
	for (int i = 2; i < chieurong2; i++)
	{
		GotoXY(2, i);
		cout << char(219);
	}
	GotoXY(2, chieurong2);
	for (int i = 0; i < chieudai2 + 1; i++)
	{
		cout << char(223);
	}
	for (int i = 2; i < chieurong2; i++)
	{
		GotoXY(2 + chieudai2, i);
		cout << char(219);
	}
}
void DrawBoard()
{
	SetTColor(1);
	GotoXY(32, 3);
	for (int i = 1; i <= chieudai - 10; i++)
		cout << char(220);
	for (int i = 4; i < chieurong; i++)
	{
		GotoXY(32, i);
		cout << char(219);
	}
	GotoXY(32, chieurong);
	for (int i = 0; i < chieudai - 10; i++)
	{
		cout << char(223);
	}
	for (int i = 4; i < chieurong; i++)
	{
		GotoXY(32 + chieudai - 11, i);
		cout << char(219);
	}
}
void DrawBoard1()
{
	SetTColor(1);
	GotoXY(32, 3);
	for (int i = 1; i <= chieudai - 10; i++)
		cout << char(220);

	for (int i = 4; i < chieurong1; i++)
	{
		GotoXY(32, i);
		cout << char(219);
	}
	GotoXY(32, chieurong1);
	for (int i = 0; i < chieudai - 10; i++)
	{
		cout << char(223);
	}
	for (int i = 4; i < chieurong1; i++)
	{
		GotoXY(32 + chieudai - 11, i);
		cout << char(219);
	}
}
void bye()
{
	system("cls");
	SetTColor(rand() % 14);
	GotoXY(37, 8);
	cout << "##### #    #   ##   #    # #    #    #   #  ####  #    #\n";
	GotoXY(37, 9);
	cout << "  #   #    #  #  #  ##   # #   #      # #  #    # #    #\n";
	GotoXY(37, 10);
	cout << "  #   ###### #    # # #  # ####        #   #    # #    #\n";
	GotoXY(37, 11);
	cout << "  #   #    # ###### #  # # #  #        #   #    # #    #\n";
	GotoXY(37, 12);
	cout << "  #   #    # #    # #   ## #   #       #   #    # #    #\n";
	GotoXY(37, 13);
	cout << "  #   #    # #    # #    # #    #      #    ####   ####\n";
	GotoXY(37, 14);
	SetTColor(0);
	GotoXY(37, 15);
	cout << "    Nhap nut bat ki de thoat....";
}
void hcmus()
{
	//SetTColor(rand() % 14);
	GotoXY(45, 13);
	cout << "#    #  ####  #    # #    #  ####\n";
	GotoXY(45, 14);
	cout << "#    # #    # ##  ## #    # #\n";
	GotoXY(45, 15);
	cout << "###### #      # ## # #    #  ####\n";
	GotoXY(45, 16);
	cout << "#    # #      #    # #    #      #\n";
	GotoXY(45, 17);
	cout << "#    # #    # #    # #    # #    #\n";
	GotoXY(45, 18);
	cout << "#    #  ####  #    #  ####   ####\n";

}