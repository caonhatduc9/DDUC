#pragma once
#include<Windows.h>
#include "pch.h"
#include "framework.h"
#include "CLIENT.h"
#include"afxsock.h"
#include"string.h"
#include <string>
#include<vector>
#include<conio.h>
#include<iostream>
void GotoXY(int x, int y);
void SetTColor(WORD color);
void FixConsoleWindow();
void noCursorType();

void DrawBoard2();
void DrawBoard();
void DrawBoard1();
void bye();
void hcmus();
